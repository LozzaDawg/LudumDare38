
var sun = new Image()
sun.src = 'assets/sun.png'

var forgeP = new Image()
forgeP.src = 'assets/forgePlanet.png'

var growthP = new Image()
growthP.src = 'assets/growthPlanet.png'

var miningP = new Image()
miningP.src = 'assets/miningPlanet.png'

var star = new Image()
star.src = 'assets/star.png'

var music = new Audio('assets/Song.wav')
music.loop=true
music.play()
